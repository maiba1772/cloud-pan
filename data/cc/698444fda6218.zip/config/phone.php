<?php

/**
 * 阿里云短信配置文件
 */
return [
    'provider'            => env('phone.provider', ''),
    'type'                => env('phone.type', 'sts'), // 临时访问权限凭证 STS(https://help.aliyun.com/zh/ram/user-guide/what-is-sts)
    'endpoint'            => env('phone.endpoint', 'dypnsapi.aliyuncs.com'),  // 阿里云 Endpoint
    'access_id'           => env('phone.access_id', ''),  // 阿里云RAM id
    'access_secret'       => env('phone.access_secret', ''), // 阿里云RAM密钥
    'access_token'        => env('phone.access_token', ''), // 阿里云访问Token (https://ram.console.aliyun.com/roles) 创建角色。格式可能为 acs:ram::<数字>:role/<自定义名字>
    'sign'                => env('phone.sign', ''),   // 短信签名
    'template'            => env('phone.template', ''),   // 短信模板
    'param'               => env('phone.param', ''),    // 短信参数，其中code为验证码。
];
