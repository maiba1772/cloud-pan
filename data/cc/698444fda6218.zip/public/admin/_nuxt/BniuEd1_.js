import {
    _ as Qe,
    V as F,
    a as g
} from "./CZ7Dih0w.js";
import {
    ak as Be,
    X as G,
    Y as O,
    al as Ze,
    am as Je,
    Z as De,
    an as et,
    r as z,
    k as P,
    s as ae,
    N as ve,
    a3 as U,
    C as l,
    A as T,
    M as B,
    a4 as K,
    ah as Ae,
    ao as be,
    ac as ie,
    ap as tt,
    aq as Me,
    ar as $e,
    as as lt,
    at as Re,
    au as nt,
    av as at,
    aw as ot,
    ax as st,
    ay as ut,
    ad as Le,
    az as fe,
    ai as it,
    aA as rt,
    aB as dt,
    $ as Ve,
    aC as ce,
    aD as ct,
    o as Fe,
    K as x,
    Q as J,
    W as Y,
    aE as Te,
    a8 as We,
    aF as pe,
    aG as mt,
    aH as vt,
    aI as ft,
    aJ as gt,
    aK as bt,
    aL as Vt,
    aM as pt,
    aN as ht,
    aO as wt,
    aP as yt,
    aQ as Ct,
    aR as xt,
    aS as St,
    d as Tt,
    F as Pe,
    D as i,
    aT as se,
    z as Ie,
    P as ke,
    L as d,
    E as H,
    aU as Pt
} from "./BzY8wVZr.js";
import {
    C as me
} from "./DxfiNTTU.js";
import {
    b as It,
    V as kt
} from "./DD323otF.js";
import {
    u as Ut
} from "./DskXjZ4n.js";
import {
    a as Ue,
    m as _t
} from "./iVis3OxH.js";
import {
    V as X
} from "./CHBEpWkP.js";
import {
    V as ue
} from "./w-BHEGo2.js"; /* empty css        */
const Et = e => {
    const {
        touchstartX: u,
        touchendX: o,
        touchstartY: s,
        touchendY: m
    } = e, n = .5, c = 16;
    e.offsetX = o - u, e.offsetY = m - s, Math.abs(e.offsetY) < n * Math.abs(e.offsetX) && (e.left && o < u - c && e.left(e), e.right && o > u + c && e.right(e)), Math.abs(e.offsetX) < n * Math.abs(e.offsetY) && (e.up && m < s - c && e.up(e), e.down && m > s + c && e.down(e))
};

function Nt(e, u) {
    const o = e.changedTouches[0];
    u.touchstartX = o.clientX, u.touchstartY = o.clientY, u.start?.({
        originalEvent: e,
        ...u
    })
}

function Bt(e, u) {
    const o = e.changedTouches[0];
    u.touchendX = o.clientX, u.touchendY = o.clientY, u.end?.({
        originalEvent: e,
        ...u
    }), Et(u)
}

function Dt(e, u) {
    const o = e.changedTouches[0];
    u.touchmoveX = o.clientX, u.touchmoveY = o.clientY, u.move?.({
        originalEvent: e,
        ...u
    })
}

function At() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    const u = {
        touchstartX: 0,
        touchstartY: 0,
        touchendX: 0,
        touchendY: 0,
        touchmoveX: 0,
        touchmoveY: 0,
        offsetX: 0,
        offsetY: 0,
        left: e.left,
        right: e.right,
        up: e.up,
        down: e.down,
        start: e.start,
        move: e.move,
        end: e.end
    };
    return {
        touchstart: o => Nt(o, u),
        touchend: o => Bt(o, u),
        touchmove: o => Dt(o, u)
    }
}

function Mt(e, u) {
    const o = u.value,
        s = o?.parent ? e.parentElement : e,
        m = o?.options ?? {
            passive: !0
        },
        n = u.instance?.$.uid;
    if (!s || !n) return;
    const c = At(u.value);
    s._touchHandlers = s._touchHandlers ?? Object.create(null), s._touchHandlers[n] = c, Be(c).forEach(v => {
        s.addEventListener(v, c[v], m)
    })
}

function $t(e, u) {
    const o = u.value?.parent ? e.parentElement : e,
        s = u.instance?.$.uid;
    if (!o?._touchHandlers || !s) return;
    const m = o._touchHandlers[s];
    Be(m).forEach(n => {
        o.removeEventListener(n, m[n])
    }), delete o._touchHandlers[s]
}
const ge = {
        mounted: Mt,
        unmounted: $t
    },
    He = Symbol.for("vuetify:v-window"),
    ze = Symbol.for("vuetify:v-window-group"),
    Xe = O({
        continuous: Boolean,
        nextIcon: {
            type: [Boolean, String, Function, Object],
            default: "$next"
        },
        prevIcon: {
            type: [Boolean, String, Function, Object],
            default: "$prev"
        },
        reverse: Boolean,
        showArrows: {
            type: [Boolean, String],
            validator: e => typeof e == "boolean" || e === "hover"
        },
        verticalArrows: [Boolean, String],
        touch: {
            type: [Object, Boolean],
            default: void 0
        },
        direction: {
            type: String,
            default: "horizontal"
        },
        modelValue: null,
        disabled: Boolean,
        selectedClass: {
            type: String,
            default: "v-window-item--active"
        },
        mandatory: {
            type: [Boolean, String],
            default: "force"
        },
        ...$e(),
        ...Me(),
        ...tt()
    }, "VWindow"),
    _e = G()({
        name: "VWindow",
        directives: {
            vTouch: ge
        },
        props: Xe(),
        emits: {
            "update:modelValue": e => !0
        },
        setup(e, u) {
            let {
                slots: o
            } = u;
            const {
                themeClasses: s
            } = Ze(e), {
                isRtl: m
            } = Je(), {
                t: n
            } = De(), c = et(e, ze), v = z(), b = P(() => m.value ? !e.reverse : e.reverse), C = ae(!1), w = P(() => {
                const y = e.direction === "vertical" ? "y" : "x",
                    k = (b.value ? !C.value : C.value) ? "-reverse" : "";
                return `v-window-${y}${k}-transition`
            }), V = ae(0), t = z(void 0), S = P(() => c.items.value.findIndex(y => c.selected.value.includes(y.id)));
            ve(S, (y, h) => {
                const k = c.items.value.length,
                    j = k - 1;
                k <= 2 ? C.value = y < h : y === j && h === 0 ? C.value = !0 : y === 0 && h === j ? C.value = !1 : C.value = y < h
            }), lt(He, {
                transition: w,
                isReversed: C,
                transitionCount: V,
                transitionHeight: t,
                rootRef: v
            });
            const a = U(() => e.continuous || S.value !== 0),
                W = U(() => e.continuous || S.value !== c.items.value.length - 1);

            function I() {
                a.value && c.prev()
            }

            function p() {
                W.value && c.next()
            }
            const D = P(() => {
                    const y = [],
                        h = {
                            icon: m.value ? e.nextIcon : e.prevIcon,
                            class: `v-window__${b.value?"right":"left"}`,
                            onClick: c.prev,
                            "aria-label": n("$vuetify.carousel.prev")
                        };
                    y.push(a.value ? o.prev ? o.prev({
                        props: h
                    }) : l(B, h, null) : T("div", null, null));
                    const k = {
                        icon: m.value ? e.prevIcon : e.nextIcon,
                        class: `v-window__${b.value?"left":"right"}`,
                        onClick: c.next,
                        "aria-label": n("$vuetify.carousel.next")
                    };
                    return y.push(W.value ? o.next ? o.next({
                        props: k
                    }) : l(B, k, null) : T("div", null, null)), y
                }),
                A = P(() => e.touch === !1 ? e.touch : {
                    ...{
                        left: () => {
                            b.value ? I() : p()
                        },
                        right: () => {
                            b.value ? p() : I()
                        },
                        start: h => {
                            let {
                                originalEvent: k
                            } = h;
                            k.stopPropagation()
                        }
                    },
                    ...e.touch === !0 ? {} : e.touch
                });
            return K(() => Ae(l(e.tag, {
                ref: v,
                class: ie(["v-window", {
                    "v-window--show-arrows-on-hover": e.showArrows === "hover",
                    "v-window--vertical-arrows": !!e.verticalArrows
                }, s.value, e.class]),
                style: be(e.style)
            }, {
                default: () => [T("div", {
                    class: "v-window__container",
                    style: {
                        height: t.value
                    }
                }, [o.default?.({
                    group: c
                }), e.showArrows !== !1 && T("div", {
                    class: ie(["v-window__controls", {
                        "v-window__controls--left": e.verticalArrows === "left" || e.verticalArrows === !0
                    }, {
                        "v-window__controls--right": e.verticalArrows === "right"
                    }])
                }, [D.value])]), o.additional?.({
                    group: c
                })]
            }), [
                [ge, A.value]
            ])), {
                group: c
            }
        }
    }),
    Ye = O({
        reverseTransition: {
            type: [Boolean, String],
            default: void 0
        },
        transition: {
            type: [Boolean, String],
            default: void 0
        },
        ...$e(),
        ...ut(),
        ...st()
    }, "VWindowItem"),
    Ee = G()({
        name: "VWindowItem",
        directives: {
            vTouch: ge
        },
        props: Ye(),
        emits: {
            "group:selected": e => !0
        },
        setup(e, u) {
            let {
                slots: o
            } = u;
            const s = Re(He),
                m = nt(e, ze),
                {
                    isBooted: n
                } = Ut();
            if (!s || !m) throw new Error("[Vuetify] VWindowItem must be used inside VWindow");
            const c = ae(!1),
                v = P(() => n.value && (s.isReversed.value ? e.reverseTransition !== !1 : e.transition !== !1));

            function b() {
                !c.value || !s || (c.value = !1, s.transitionCount.value > 0 && (s.transitionCount.value -= 1, s.transitionCount.value === 0 && (s.transitionHeight.value = void 0)))
            }

            function C() {
                c.value || !s || (c.value = !0, s.transitionCount.value === 0 && (s.transitionHeight.value = fe(s.rootRef.value?.clientHeight)), s.transitionCount.value += 1)
            }
            
            function patchPhone() {
                c.value || !s || (c.value = !0, s.transitionCount.value === 0 && (s.transitionHeight.value = fe(s.rootRef.value?.clientHeight)), s.transitionCount.value += 1)
            }

            function w() {
                b()
            }

            function V(a) {
                c.value && Le(() => {
                    !v.value || !c.value || !s || (s.transitionHeight.value = fe(a.clientHeight))
                })
            }
            const t = P(() => {
                    const a = s.isReversed.value ? e.reverseTransition : e.transition;
                    return v.value ? {
                        name: typeof a != "string" ? s.transition.value : a,
                        onBeforeEnter: C,
                        onAfterEnter: b,
                        onEnterCancelled: w,
                        onBeforeLeave: C,
                        onAfterLeave: b,
                        onLeaveCancelled: w,
                        onEnter: V
                    } : !1
                }),
                {
                    hasContent: S
                } = at(e, m.isSelected);
            return K(() => l(ot, {
                transition: t.value,
                disabled: !n.value
            }, {
                default: () => [Ae(T("div", {
                    class: ie(["v-window-item", m.selectedClass.value, e.class]),
                    style: be(e.style)
                }, [S.value && o.default?.()]), [
                    [it, m.isSelected.value]
                ])]
            })), {
                groupItem: m
            }
        }
    }),
    Rt = 50,
    Lt = 500;

function Ft(e) {
    let {
        toggleUpDown: u
    } = e, o = -1, s = -1;
    rt(n);

    function m(v) {
        n(), c(v), window.addEventListener("pointerup", n), document.addEventListener("blur", n), o = window.setTimeout(() => {
            s = window.setInterval(() => c(v), Rt)
        }, Lt)
    }

    function n() {
        window.clearTimeout(o), window.clearInterval(s), window.removeEventListener("pointerup", n), document.removeEventListener("blur", n)
    }

    function c(v) {
        u(v === "up")
    }
    return {
        holdStart: m,
        holdStop: n
    }
}
const Wt = O({
        controlVariant: {
            type: String,
            default: "default"
        },
        inset: Boolean,
        hideInput: Boolean,
        modelValue: {
            type: Number,
            default: null
        },
        min: {
            type: Number,
            default: Number.MIN_SAFE_INTEGER
        },
        max: {
            type: Number,
            default: Number.MAX_SAFE_INTEGER
        },
        step: {
            type: Number,
            default: 1
        },
        precision: {
            type: Number,
            default: 0
        },
        minFractionDigits: {
            type: Number,
            default: null
        },
        decimalSeparator: {
            type: String,
            validator: e => !e || e.length === 1
        },
        ...pe(mt(), ["modelValue", "validationValue"])
    }, "VNumberInput"),
    Ne = G()({
        name: "VNumberInput",
        props: {
            ...Wt()
        },
        emits: {
            "update:focused": e => !0,
            "update:modelValue": e => !0
        },
        setup(e, u) {
            let {
                slots: o
            } = u;
            const s = z(),
                {
                    holdStart: m,
                    holdStop: n
                } = Ft({
                    toggleUpDown: ee
                }),
                c = dt(e),
                v = P(() => c.isDisabled.value || c.isReadonly.value),
                b = ae(e.focused),
                {
                    decimalSeparator: C
                } = De(),
                w = P(() => e.decimalSeparator?.[0] || C.value);

            function V(r) {
                let f = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e.precision,
                    E = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
                const $ = f == null ? String(r) : r.toFixed(f);
                if (b.value && E) return Number($).toString().replace(".", w.value);
                if (e.minFractionDigits === null || f !== null && f < e.minFractionDigits) return $.replace(".", w.value);
                let [Q, N] = $.split(".");
                return N = (N ?? "").padEnd(e.minFractionDigits, "0").replace(new RegExp(`(?<=\\d{${e.minFractionDigits}})0+$`, "g"), ""), [Q, N].filter(Boolean).join(w.value)
            }
            const t = Ve(e, "modelValue", null, r => r ?? null, r => r == null ? r ?? null : ce(Number(r), e.min, e.max)),
                S = ae(null);
            ct(() => {
                b.value && !v.value || (t.value == null ? S.value = null : isNaN(t.value) || (S.value = V(t.value)))
            });
            const a = P({
                    get: () => S.value,
                    set(r) {
                        if (r === null || r === "") {
                            t.value = null, S.value = null;
                            return
                        }
                        const f = Number(r.replace(w.value, "."));
                        !isNaN(f) && f <= e.max && f >= e.min && (t.value = f, S.value = r)
                    }
                }),
                W = P(() => v.value ? !1 : (t.value ?? 0) + e.step <= e.max),
                I = P(() => v.value ? !1 : (t.value ?? 0) - e.step >= e.min),
                p = P(() => e.hideInput ? "stacked" : e.controlVariant),
                D = U(() => p.value === "split" ? "$plus" : "$collapse"),
                A = U(() => p.value === "split" ? "$minus" : "$expand"),
                y = U(() => p.value === "split" ? "default" : "small"),
                h = U(() => p.value === "stacked" ? "auto" : "100%"),
                k = {
                    props: {
                        onClick: q,
                        onPointerup: _,
                        onPointerdown: ye,
                        onPointercancel: _
                    }
                },
                j = {
                    props: {
                        onClick: q,
                        onPointerup: _,
                        onPointerdown: Ce,
                        onPointercancel: _
                    }
                };
            ve(() => e.precision, () => xe()), ve(() => e.minFractionDigits, () => xe()), Fe(() => {
                de()
            });

            function M(r) {
                if (r == null) return 0;
                const f = r.toString(),
                    E = f.indexOf(".");
                return ~E ? f.length - E : 0
            }

            function ee() {
                let r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
                if (v.value) return;
                if (t.value == null) {
                    a.value = V(ce(0, e.min, e.max));
                    return
                }
                let f = Math.max(M(t.value), M(e.step));
                e.precision != null && (f = Math.max(f, e.precision)), r ? W.value && (a.value = V(t.value + e.step, f)) : I.value && (a.value = V(t.value - e.step, f))
            }

            function we(r) {
                if (!r.data) return;
                const f = r.target,
                    {
                        value: E,
                        selectionStart: $,
                        selectionEnd: Q
                    } = f ?? {},
                    N = E ? E.slice(0, $) + r.data + E.slice(Q) : r.data,
                    Z = vt(N, e.precision, w.value);
                if (new RegExp(`^-?\\d*${ft(w.value)}?\\d*$`).test(N) || (r.preventDefault(), f.value = Z), e.precision != null) {
                    if (N.split(w.value)[1]?.length > e.precision) {
                        r.preventDefault(), f.value = Z;
                        const oe = ($ ?? 0) + r.data.length;
                        f.setSelectionRange(oe, oe)
                    }
                    e.precision === 0 && N.includes(w.value) && (r.preventDefault(), f.value = Z)
                }
            }
            async function re(r) {
                ["Enter", "ArrowLeft", "ArrowRight", "Backspace", "Delete", "Tab"].includes(r.key) || r.ctrlKey || ["ArrowDown", "ArrowUp"].includes(r.key) && (r.preventDefault(), r.stopPropagation(), de(), await Le(), r.key === "ArrowDown" ? ee(!1) : ee())
            }

            function q(r) {
                r.stopPropagation()
            }

            function _(r) {
                r.currentTarget?.releasePointerCapture(r.pointerId), r.preventDefault(), n()
            }

            function ye(r) {
                r.currentTarget?.setPointerCapture(r.pointerId), r.preventDefault(), r.stopPropagation(), m("up")
            }

            function Ce(r) {
                r.currentTarget?.setPointerCapture(r.pointerId), r.preventDefault(), r.stopPropagation(), m("down")
            }

            function de() {
                if (v.value || !s.value) return;
                const r = s.value.value,
                    f = Number(r.replace(w.value, "."));
                r && !isNaN(f) ? a.value = V(ce(f, e.min, e.max)) : a.value = null
            }

            function xe() {
                v.value || (a.value = t.value !== null && !isNaN(t.value) ? V(t.value, e.precision, !1) : null)
            }

            function Oe() {
                if (!v.value) {
                    if (t.value === null || isNaN(t.value)) {
                        a.value = null;
                        return
                    }
                    a.value = t.value.toString().replace(".", w.value)
                }
            }

            function Ke() {
                Oe()
            }

            function je() {
                de()
            }
            return K(() => {
                const {
                    modelValue: r,
                    ...f
                } = x.filterProps(e);

                function E() {
                    return o.increment ? l(Te, {
                        key: "increment-defaults",
                        defaults: {
                            VBtn: {
                                disabled: !W.value,
                                flat: !0,
                                height: h.value,
                                size: y.value,
                                icon: D.value
                            }
                        }
                    }, {
                        default: () => [o.increment(k)]
                    }) : l(B, {
                        "aria-hidden": "true",
                        "data-testid": "increment",
                        disabled: !W.value,
                        flat: !0,
                        height: h.value,
                        icon: D.value,
                        key: "increment-btn",
                        onClick: q,
                        onPointerdown: ye,
                        onPointerup: _,
                        onPointercancel: _,
                        size: y.value,
                        tabindex: "-1"
                    }, null)
                }

                function $() {
                    return o.decrement ? l(Te, {
                        key: "decrement-defaults",
                        defaults: {
                            VBtn: {
                                disabled: !I.value,
                                flat: !0,
                                height: h.value,
                                size: y.value,
                                icon: A.value
                            }
                        }
                    }, {
                        default: () => [o.decrement(j)]
                    }) : l(B, {
                        "aria-hidden": "true",
                        "data-testid": "decrement",
                        disabled: !I.value,
                        flat: !0,
                        height: h.value,
                        icon: A.value,
                        key: "decrement-btn",
                        onClick: q,
                        onPointerdown: Ce,
                        onPointerup: _,
                        onPointercancel: _,
                        size: y.value,
                        tabindex: "-1"
                    }, null)
                }

                function Q() {
                    return T("div", {
                        class: "v-number-input__control"
                    }, [$(), l(ue, {
                        vertical: p.value !== "stacked"
                    }, null), E()])
                }

                function N() {
                    return !e.hideInput && !e.inset ? l(ue, {
                        vertical: !0
                    }, null) : void 0
                }
                const Z = p.value === "split" ? T("div", {
                        class: "v-number-input__control"
                    }, [l(ue, {
                        vertical: !0
                    }, null), E()]) : e.reverse || p.value === "hidden" ? void 0 : T(J, null, [N(), Q()]),
                    oe = o["append-inner"] || Z,
                    Se = p.value === "split" ? T("div", {
                        class: "v-number-input__control"
                    }, [$(), l(ue, {
                        vertical: !0
                    }, null)]) : e.reverse && p.value !== "hidden" ? T(J, null, [Q(), N()]) : void 0,
                    qe = o["prepend-inner"] || Se;
                return l(x, Y({
                    ref: s
                }, f, {
                    modelValue: a.value,
                    "onUpdate:modelValue": R => a.value = R,
                    focused: b.value,
                    "onUpdate:focused": R => b.value = R,
                    validationValue: t.value,
                    onBeforeinput: we,
                    onFocus: Ke,
                    onBlur: je,
                    onKeydown: re,
                    class: ["v-number-input", {
                        "v-number-input--default": p.value === "default",
                        "v-number-input--hide-input": e.hideInput,
                        "v-number-input--inset": e.inset,
                        "v-number-input--reverse": e.reverse,
                        "v-number-input--split": p.value === "split",
                        "v-number-input--stacked": p.value === "stacked"
                    }, e.class],
                    style: e.style,
                    inputmode: "decimal"
                }), {
                    ...o,
                    "append-inner": oe ? function() {
                        for (var R = arguments.length, te = new Array(R), L = 0; L < R; L++) te[L] = arguments[L];
                        return T(J, null, [o["append-inner"]?.(...te), Z])
                    } : void 0,
                    "prepend-inner": qe ? function() {
                        for (var R = arguments.length, te = new Array(R), L = 0; L < R; L++) te[L] = arguments[L];
                        return T(J, null, [Se, o["prepend-inner"]?.(...te)])
                    } : void 0
                })
            }), We({}, s)
        }
    }),
    he = Symbol.for("vuetify:v-tabs"),
    Ht = O({
        fixed: Boolean,
        sliderColor: String,
        hideSlider: Boolean,
        direction: {
            type: String,
            default: "horizontal"
        },
        ...pe(bt({
            selectedClass: "v-tab--selected",
            variant: "text"
        }), ["active", "block", "flat", "location", "position", "symbol"])
    }, "VTab"),
    le = G()({
        name: "VTab",
        props: Ht(),
        setup(e, u) {
            let {
                slots: o,
                attrs: s
            } = u;
            const {
                textColorClasses: m,
                textColorStyles: n
            } = gt(() => e.sliderColor), c = z(), v = z(), b = P(() => e.direction === "horizontal"), C = P(() => c.value?.group?.isSelected.value ?? !1);

            function w(V) {
                let {
                    value: t
                } = V;
                if (t) {
                    const S = c.value?.$el.parentElement?.querySelector(".v-tab--selected .v-tab__slider"),
                        a = v.value;
                    if (!S || !a) return;
                    const W = getComputedStyle(S).color,
                        I = S.getBoundingClientRect(),
                        p = a.getBoundingClientRect(),
                        D = b.value ? "x" : "y",
                        A = b.value ? "X" : "Y",
                        y = b.value ? "right" : "bottom",
                        h = b.value ? "width" : "height",
                        k = I[D],
                        j = p[D],
                        M = k > j ? I[y] - p[y] : I[D] - p[D],
                        ee = Math.sign(M) > 0 ? b.value ? "right" : "bottom" : Math.sign(M) < 0 ? b.value ? "left" : "top" : "center",
                        re = (Math.abs(M) + (Math.sign(M) < 0 ? I[h] : p[h])) / Math.max(I[h], p[h]) || 0,
                        q = I[h] / p[h] || 0,
                        _ = 1.5;
                    Vt(a, {
                        backgroundColor: [W, "currentcolor"],
                        transform: [`translate${A}(${M}px) scale${A}(${q})`, `translate${A}(${M/_}px) scale${A}(${(re-1)/_+1})`, "none"],
                        transformOrigin: Array(3).fill(ee)
                    }, {
                        duration: 225,
                        easing: pt
                    })
                }
            }
            return K(() => {
                const V = B.filterProps(e);
                return l(B, Y({
                    symbol: he,
                    ref: c,
                    class: ["v-tab", e.class],
                    style: e.style,
                    tabindex: C.value ? 0 : -1,
                    role: "tab",
                    "aria-selected": String(C.value),
                    active: !1
                }, V, s, {
                    block: e.fixed,
                    maxWidth: e.fixed ? 300 : void 0,
                    "onGroup:selected": w
                }), {
                    ...o,
                    default: () => T(J, null, [o.default?.() ?? e.text, !e.hideSlider && T("div", {
                        ref: v,
                        class: ie(["v-tab__slider", m.value]),
                        style: be(n.value)
                    }, null)])
                })
            }), We({}, c)
        }
    }),
    zt = O({
        ...pe(Xe(), ["continuous", "nextIcon", "prevIcon", "showArrows", "touch", "mandatory"])
    }, "VTabsWindow"),
    Ge = G()({
        name: "VTabsWindow",
        props: zt(),
        emits: {
            "update:modelValue": e => !0
        },
        setup(e, u) {
            let {
                slots: o
            } = u;
            const s = Re(he, null),
                m = Ve(e, "modelValue"),
                n = P({
                    get() {
                        return m.value != null || !s ? m.value : s.items.value.find(c => s.selected.value.includes(c.id))?.value
                    },
                    set(c) {
                        m.value = c
                    }
                });
            return K(() => {
                const c = _e.filterProps(e);
                return l(_e, Y({
                    _as: "VTabsWindow"
                }, c, {
                    modelValue: n.value,
                    "onUpdate:modelValue": v => n.value = v,
                    class: ["v-tabs-window", e.class],
                    style: e.style,
                    mandatory: !1,
                    touch: !1
                }), o)
            }), {}
        }
    }),
    Xt = O({
        ...Ye()
    }, "VTabsWindowItem"),
    ne = G()({
        name: "VTabsWindowItem",
        props: Xt(),
        setup(e, u) {
            let {
                slots: o
            } = u;
            return K(() => {
                const s = Ee.filterProps(e);
                return l(Ee, Y({
                    _as: "VTabsWindowItem"
                }, s, {
                    class: ["v-tabs-window-item", e.class],
                    style: e.style
                }), o)
            }), {}
        }
    });

function Yt(e) {
    return e ? e.map(u => St(u) ? u : {
        text: u,
        value: u
    }) : []
}
const Gt = O({
        alignTabs: {
            type: String,
            default: "start"
        },
        color: String,
        fixedTabs: Boolean,
        items: {
            type: Array,
            default: () => []
        },
        stacked: Boolean,
        bgColor: String,
        grow: Boolean,
        height: {
            type: [Number, String],
            default: void 0
        },
        hideSlider: Boolean,
        sliderColor: String,
        ..._t({
            mandatory: "force",
            selectedClass: "v-tab-item--selected"
        }),
        ...xt(),
        ...Me()
    }, "VTabs"),
    Ot = G()({
        name: "VTabs",
        props: Gt(),
        emits: {
            "update:modelValue": e => !0
        },
        setup(e, u) {
            let {
                attrs: o,
                slots: s
            } = u;
            const m = Ve(e, "modelValue"),
                n = P(() => Yt(e.items)),
                {
                    densityClasses: c
                } = ht(e),
                {
                    backgroundColorClasses: v,
                    backgroundColorStyles: b
                } = wt(() => e.bgColor),
                {
                    scopeId: C
                } = yt();
            return Ct({
                VTab: {
                    color: U(() => e.color),
                    direction: U(() => e.direction),
                    stacked: U(() => e.stacked),
                    fixed: U(() => e.fixedTabs),
                    sliderColor: U(() => e.sliderColor),
                    hideSlider: U(() => e.hideSlider)
                }
            }), K(() => {
                const w = Ue.filterProps(e),
                    V = !!(s.window || e.items.length > 0);
                return T(J, null, [l(Ue, Y(w, {
                    modelValue: m.value,
                    "onUpdate:modelValue": t => m.value = t,
                    class: ["v-tabs", `v-tabs--${e.direction}`, `v-tabs--align-tabs-${e.alignTabs}`, {
                        "v-tabs--fixed-tabs": e.fixedTabs,
                        "v-tabs--grow": e.grow,
                        "v-tabs--stacked": e.stacked
                    }, c.value, v.value, e.class],
                    style: [{
                        "--v-tabs-height": fe(e.height)
                    }, b.value, e.style],
                    role: "tablist",
                    symbol: he
                }, C, o), {
                    default: () => [s.default?.() ?? n.value.map(t => s.tab?.({
                        item: t
                    }) ?? l(le, Y(t, {
                        key: t.text,
                        value: t.value
                    }), {
                        default: s[`tab.${t.value}`] ? () => s[`tab.${t.value}`]?.({
                            item: t
                        }) : void 0
                    }))]
                }), V && l(Ge, Y({
                    modelValue: m.value,
                    "onUpdate:modelValue": t => m.value = t,
                    key: "tabs-window"
                }, C), {
                    default: () => [n.value.map(t => s.item?.({
                        item: t
                    }) ?? l(ne, {
                        value: t.value
                    }, {
                        default: () => s[`item.${t.value}`]?.({
                            item: t
                        })
                    })), s.window?.()]
                })])
            }), {}
        }
    }),
    nl = Tt({
        __name: "system",
        setup(e) {
            const u = z(""),
                o = [{
                    title: "开启",
                    value: !0
                }, {
                    title: "关闭",
                    value: !1
                }],
                s = [{
                    title: "smtp",
                    value: "smtp"
                }, {
                    title: "sendmail",
                    value: "sendmail"
                }, {
                    title: "mail",
                    value: "mail"
                }],
                m = [{
                    title: "null",
                    value: "null"
                }, {
                    title: "ssl",
                    value: "ssl"
                }, {
                    title: "tls",
                    value: "tls"
                }],
                n = z([]),
                c = z([]),
                v = () => {
                    se.getConfig().then(V => {
                        n.value = me.deepClone(V.data), c.value = me.deepClone(V.data)
                    })
                },
                b = () => {
                    se.postConfig(n.value.master).then(() => {
                        v()
                    })
                },
                C = () => {
                    let V = me.removeCommonProperties(n.value.mail, c.value.mail);
                    se.patchEmail(V).then(() => {
                        v()
                    })
                },
                patchPhone = () => {
                    let remainPhone = me.removeCommonProperties(n.value.phone, c.value.phone);
                    se.patchPhone(remainPhone).then(() => {
                        v()
                    })
                },
                w = () => {
                    se.postSite(n.value.system).then(() => {
                        v()
                    })
                };
            return Fe(() => {
                v()
            }), (V, t) => {
                const S = Qe;
                return Ie(), Pe(S, {
                    name: "root"
                }, {
                    default: i(() => [l(F, {
                        class: "pt-2"
                    }, {
                        default: i(() => [l(g, {
                            cols: "6"
                        }, {
                            default: i(() => t[27] || (t[27] = [T("h1", {
                                class: "text-primary font-weight-bold"
                            }, "系统", -1)])),
                            _: 1,
                            __: [27]
                        })]),
                        _: 1
                    }), l(F, null, {
                        default: i(() => [l(g, {
                            cols: "12"
                        }, {
                            default: i(() => [l(It, null, {
                                default: i(() => [l(Ot, {
                                    modelValue: d(u),
                                    "onUpdate:modelValue": t[0] || (t[0] = a => ke(u) ? u.value = a : null),
                                    color: "primary"
                                }, {
                                    default: i(() => [l(le, {
                                        value: "tab1"
                                    }, {
                                        default: i(() => t[28] || (t[28] = [H("基本信息", -1)])),
                                        _: 1,
                                        __: [28]
                                    }), l(le, {
                                        value: "tab2"
                                    }, {
                                        default: i(() => t[29] || (t[29] = [H("极验配置", -1)])),
                                        _: 1,
                                        __: [29]
                                    }), l(le, {
                                        value: "tab3"
                                    }, {
                                        default: i(() => t[30] || (t[30] = [H("邮箱配置", -1)])),
                                        _: 1,
                                        __: [30]
                                    }), l(le, {
                                        value: "tab4"
                                    }, {
                                        default: i(() => t[37] || (t[37] = [H("短信配置", -1)])),
                                        _: 1,
                                        __: [37]
                                    }), l(le, {
                                        value: "tab5"
                                    }, {
                                        default: i(() => t[31] || (t[31] = [H("其他配置", -1)])),
                                        _: 1,
                                        __: [31]
                                    })]),
                                    _: 1
                                }, 8, ["modelValue"]), l(kt, null, {
                                    default: i(() => [d(n).system ? (Ie(), Pe(Ge, {
                                        key: 0,
                                        modelValue: d(u),
                                        "onUpdate:modelValue": t[26] || (t[26] = a => ke(u) ? u.value = a : null)
                                    }, {
                                        default: i(() => [l(ne, {
                                            value: "tab1"
                                        }, {
                                            default: i(() => [l(F, {
                                                dense: ""
                                            }, {
                                                default: i(() => [l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "站点域名",
                                                        placeholder: "www.lovecards.cn",
                                                        modelValue: d(n).system.siteUrl,
                                                        "onUpdate:modelValue": t[1] || (t[1] = a => d(n).system.siteUrl = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "站点名",
                                                        placeholder: "倾心倾意网",
                                                        modelValue: d(n).system.siteName,
                                                        "onUpdate:modelValue": t[2] || (t[2] = a => d(n).system.siteName = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "站点标题",
                                                        placeholder: "LoveCards",
                                                        modelValue: d(n).system.siteTitle,
                                                        "onUpdate:modelValue": t[3] || (t[3] = a => d(n).system.siteTitle = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "站点关键词",
                                                        hint: "(meta keywords)",
                                                        placeholder: "论坛,社区,小圈子,表白墙",
                                                        modelValue: d(n).system.siteKeywords,
                                                        "onUpdate:modelValue": t[4] || (t[4] = a => d(n).system.siteKeywords = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "站点介绍",
                                                        hint: "(meta description)",
                                                        placeholder: "这是一个由LoveCards强力驱动的社区",
                                                        variant: "underlined",
                                                        modelValue: d(n).system.siteDes,
                                                        "onUpdate:modelValue": t[5] || (t[5] = a => d(n).system.siteDes = a),
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "站点备案信息",
                                                        placeholder: "ICPxxxxxxx",
                                                        modelValue: d(n).system.siteICPId,
                                                        "onUpdate:modelValue": t[6] || (t[6] = a => d(n).system.siteICPId = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "站点版权信息",
                                                        placeholder: "lovecards.cn版权所有",
                                                        modelValue: d(n).system.siteCopyright,
                                                        "onUpdate:modelValue": t[7] || (t[7] = a => d(n).system.siteCopyright = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                })]),
                                                _: 1
                                            }), l(F, null, {
                                                default: i(() => [l(g, {
                                                    cols: "12"
                                                }, {
                                                    default: i(() => [l(B, {
                                                        onClick: w,
                                                        class: "float-right",
                                                        color: "accent"
                                                    }, {
                                                        default: i(() => t[32] || (t[32] = [H("提交", -1)])),
                                                        _: 1,
                                                        __: [32]
                                                    })]),
                                                    _: 1
                                                })]),
                                                _: 1
                                            })]),
                                            _: 1
                                        }), l(ne, {
                                            value: "tab2"
                                        }, {
                                            default: i(() => [l(F, {
                                                dense: ""
                                            }, {
                                                default: i(() => [l(g, {
                                                    cols: "12",
                                                    sm: "4"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "验证 ID",
                                                        placeholder: "id",
                                                        modelValue: d(n).master.Geetest.Id,
                                                        "onUpdate:modelValue": t[8] || (t[8] = a => d(n).master.Geetest.Id = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "4"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "验证 Key",
                                                        placeholder: "key",
                                                        modelValue: d(n).master.Geetest.Key,
                                                        "onUpdate:modelValue": t[9] || (t[9] = a => d(n).master.Geetest.Key = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "4"
                                                }, {
                                                    default: i(() => [l(X, {
                                                        label: "验证模块状态",
                                                        "item-title": "title",
                                                        "item-value": "value",
                                                        modelValue: d(n).master.Geetest.Status,
                                                        "onUpdate:modelValue": t[10] || (t[10] = a => d(n).master.Geetest.Status = a),
                                                        subtitle: "tip",
                                                        items: o,
                                                        variant: "underlined"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                })]),
                                                _: 1
                                            }), l(F, null, {
                                                default: i(() => [l(g, {
                                                    cols: "12"
                                                }, {
                                                    default: i(() => [t[34] || (t[34] = T("a", {
                                                        class: "text-accent text-decoration-none mt-2 d-inline-block",
                                                        href: "https://forum.lovecards.cn/d/26"
                                                    }, "不会配置？", -1)), l(B, {
                                                        onClick: b,
                                                        class: "float-right",
                                                        color: "accent"
                                                    }, {
                                                        default: i(() => t[33] || (t[33] = [H("提交", -1)])),
                                                        _: 1,
                                                        __: [33]
                                                    })]),
                                                    _: 1,
                                                    __: [34]
                                                })]),
                                                _: 1
                                            })]),
                                            _: 1
                                        }), l(ne, {
                                            value: "tab3"
                                        }, {
                                            default: i(() => [l(F, {
                                                dense: ""
                                            }, {
                                                default: i(() => [l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(X, {
                                                        label: "邮件驱动",
                                                        "item-title": "title",
                                                        "item-value": "value",
                                                        subtitle: "tip",
                                                        items: s,
                                                        modelValue: d(n).mail.driver,
                                                        "onUpdate:modelValue": t[11] || (t[11] = a => d(n).mail.driver = a),
                                                        variant: "underlined"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(X, {
                                                        label: "加密方式",
                                                        "item-title": "title",
                                                        "item-value": "value",
                                                        subtitle: "tip",
                                                        items: m,
                                                        modelValue: d(n).mail.security,
                                                        "onUpdate:modelValue": t[12] || (t[12] = a => d(n).mail.security = a),
                                                        variant: "underlined"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "SMTPHost",
                                                        placeholder: "mail.lovecard.cn",
                                                        modelValue: d(n).mail.host,
                                                        "onUpdate:modelValue": t[13] || (t[13] = a => d(n).mail.host = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "SMTPPort",
                                                        placeholder: "25",
                                                        modelValue: d(n).mail.port,
                                                        "onUpdate:modelValue": t[14] || (t[14] = a => d(n).mail.port = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "SMTP邮箱地址",
                                                        placeholder: "xxx@lovecards.cn",
                                                        modelValue: d(n).mail.addr,
                                                        "onUpdate:modelValue": t[15] || (t[15] = a => d(n).mail.addr = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "SMTP密码",
                                                        placeholder: "",
                                                        modelValue: d(n).mail.pass,
                                                        "onUpdate:modelValue": t[16] || (t[16] = a => d(n).mail.pass = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "发件人昵称",
                                                        modelValue: d(n).mail.name,
                                                        "onUpdate:modelValue": t[17] || (t[17] = a => d(n).mail.name = a),
                                                        placeholder: "倾心倾意邮递员",
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                })]),
                                                _: 1
                                            }), l(F, null, {
                                                default: i(() => [l(g, {
                                                    cols: "12"
                                                }, {
                                                    default: i(() => [l(B, {
                                                        onClick: C,
                                                        class: "float-right",
                                                        color: "accent"
                                                    }, {
                                                        default: i(() => t[35] || (t[35] = [H("提交", -1)])),
                                                        _: 1,
                                                        __: [35]
                                                    })]),
                                                    _: 1
                                                })]),
                                                _: 1
                                            })]),
                                            _: 1
                                        }), l(ne, {
                                        	value: "tab4"
                                        }, {
                                	        default: i(() => [l(F, {
                                    		    dense: ""
                                    	    }, {
                                		    default: i(() => [
                                			// 1. 服务商下拉框
                                    			l(g, {
                                    				cols: "12",
                                    				sm: "6"
                                			}, {
                                				default: i(() => [l(X, {
                                					label: "服务商",
                                					"item-title": "title",
                                					"item-value": "value",
                                					subtitle: "tip",
                                					items: [
                                						{ title: "请选择", value: "" },
                                						{ title: "阿里云（支持号码认证）", value: "aliyun" }
                                					],
                                					modelValue: d(n).phone.provider,
                                					"onUpdate:modelValue": t[38] || (t[38] = a => d(n).phone.provider = a),
                                					variant: "underlined"
                                				}, null, 8, ["modelValue"])]),
                                				_: 1
                                			}),
                                
                                			// 2. RAM 用户访问ID
                                			l(g, {
                                				cols: "12",
                                				sm: "6"
                                			}, {
                                				default: i(() => [l(x, {
                                					label: "RAM 用户访问ID",
                                					placeholder: "",
                                					modelValue: d(n).phone.access_id,
                                					"onUpdate:modelValue": t[39] || (t[39] = a => d(n).phone.access_id = a),
                                					variant: "underlined",
                                					color: "accent"
                                				}, null, 8, ["modelValue"])]),
                                				_: 1
                                			}),
                                
                                			// 3. RAM 用户访问SECRET
                                			l(g, {
                                				cols: "12",
                                				sm: "6"
                                			}, {
                                				default: i(() => [l(x, {
                                					label: "RAM 用户访问SECRET",
                                					placeholder: "",
                                					modelValue: d(n).phone.access_secret,
                                					"onUpdate:modelValue": t[40] || (t[40] = a => d(n).phone.access_secret = a),
                                					variant: "underlined",
                                					color: "accent"
                                				}, null, 8, ["modelValue"])]),
                                				_: 1
                                			}),
                                
                                			// 4. 角色访问TOKEN
                                			l(g, {
                                				cols: "12",
                                				sm: "6"
                                			}, {
                                				default: i(() => [l(x, {
                                					label: "角色访问TOKEN",
                                					placeholder: "acs:ram::<数字>:role/<自定义名字>",
                                					modelValue: d(n).phone.access_token,
                                					"onUpdate:modelValue": t[41] || (t[41] = a => d(n).phone.access_token = a),
                                					variant: "underlined",
                                					color: "accent"
                                				}, null, 8, ["modelValue"])]),
                                				_: 1
                                			}),
                                
                                			// 5. 短信签名
                                			l(g, {
                                				cols: "12",
                                				sm: "6"
                                			}, {
                                				default: i(() => [l(x, {
                                					label: "短信签名",
                                					placeholder: "",
                                					modelValue: d(n).phone.sign,
                                					"onUpdate:modelValue": t[42] || (t[42] = a => d(n).phone.sign = a),
                                					variant: "underlined",
                                					color: "accent"
                                				}, null, 8, ["modelValue"])]),
                                				_: 1
                                			}),
                                
                                			// 6. 短信模板
                                			l(g, {
                                				cols: "12",
                                				sm: "6"
                                			}, {
                                				default: i(() => [l(x, {
                                					label: "短信模板",
                                					placeholder: "SMS_xxxx",
                                					modelValue: d(n).phone.template,
                                					"onUpdate:modelValue": t[43] || (t[43] = a => d(n).phone.template = a),
                                					variant: "underlined",
                                					color: "accent"
                                				}, null, 8, ["modelValue"])]),
                                				_: 1
                                			}),
                                
                                			// 7. 参数字符串
                                			l(g, {
                                				cols: "12",
                                				sm: "6"
                                			}, {
                                				default: i(() => [l(x, {
                                					label: "参数字符串",
                                					placeholder: "{\"code\":\"$code\",\"min\":\"5\"}",
                                					modelValue: d(n).phone.param,
                                					"onUpdate:modelValue": t[44] || (t[44] = a => d(n).phone.param = a),
                                					variant: "underlined",
                                					color: "accent"
                                				}, null, 8, ["modelValue"])]),
                                				_: 1
                                			})
                                		]),
                                		_: 1
                                	}), l(F, null, {
                                		default: i(() => [l(g, {
                                			cols: "12"
                                		}, {
                                			default: i(() => [l(B, {
                                				onClick: patchPhone,
                                				class: "float-right",
                                				color: "accent"
                                			}, {
                                				default: i(() => t[45] || (t[45] = [H("提交", -1)])),
                                				_: 1,
                                				__: [45]
                                			})]),
                                			_: 1
                                		})]),
                                		_: 1
                                	})]),
                                	_: 1
                                }), l(ne, {
                                            value: "tab5"
                                        }, {
                                            default: i(() => [l(F, {
                                                dense: ""
                                            }, {
                                                default: i(() => [l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(X, {
                                                        label: "访客模式",
                                                        "item-title": "title",
                                                        "item-value": "value",
                                                        subtitle: "tip",
                                                        items: o,
                                                        modelValue: d(n).master.System.VisitorMode,
                                                        "onUpdate:modelValue": t[18] || (t[18] = a => d(n).master.System.VisitorMode = a),
                                                        variant: "underlined"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(X, {
                                                        label: "注册验证(邮件)",
                                                        "item-title": "title",
                                                        "item-value": "value",
                                                        subtitle: "tip",
                                                        items: o,
                                                        modelValue: d(n).master.UserAuth.Captcha,
                                                        "onUpdate:modelValue": t[19] || (t[19] = a => d(n).master.UserAuth.Captcha = a),
                                                        variant: "underlined"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "图片大小限制",
                                                        hint: "(单位：M/每张)",
                                                        placeholder: "2",
                                                        modelValue: d(n).master.Upload.UserImageSize,
                                                        "onUpdate:modelValue": t[20] || (t[20] = a => d(n).master.Upload.UserImageSize = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(x, {
                                                        label: "图片格式限制",
                                                        hint: "(使用逗号[,]分割)",
                                                        placeholder: "jpg,png,gif,webp",
                                                        modelValue: d(n).master.Upload.UserImageExt,
                                                        "onUpdate:modelValue": t[21] || (t[21] = a => d(n).master.Upload.UserImageExt = a),
                                                        variant: "underlined",
                                                        color: "accent"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(Ne, {
                                                        reverse: !1,
                                                        controlVariant: "split",
                                                        label: "卡片图集上限",
                                                        hideInput: !1,
                                                        inset: !1,
                                                        modelValue: d(n).master.Cards.PictureLimit,
                                                        "onUpdate:modelValue": t[22] || (t[22] = a => d(n).master.Cards.PictureLimit = a)
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(Ne, {
                                                        reverse: !1,
                                                        controlVariant: "split",
                                                        label: "卡片标签上限",
                                                        hideInput: !1,
                                                        inset: !1,
                                                        modelValue: d(n).master.Cards.TagLimit,
                                                        "onUpdate:modelValue": t[23] || (t[23] = a => d(n).master.Cards.TagLimit = a)
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(X, {
                                                        label: "卡片审核",
                                                        "item-title": "title",
                                                        "item-value": "value",
                                                        subtitle: "tip",
                                                        items: o,
                                                        modelValue: d(n).master.Cards.Approve,
                                                        "onUpdate:modelValue": t[24] || (t[24] = a => d(n).master.Cards.Approve = a),
                                                        variant: "underlined"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12",
                                                    sm: "6"
                                                }, {
                                                    default: i(() => [l(X, {
                                                        label: "评论审核",
                                                        "item-title": "title",
                                                        "item-value": "value",
                                                        subtitle: "tip",
                                                        items: o,
                                                        modelValue: d(n).master.Comments.Approve,
                                                        "onUpdate:modelValue": t[25] || (t[25] = a => d(n).master.Comments.Approve = a),
                                                        variant: "underlined"
                                                    }, null, 8, ["modelValue"])]),
                                                    _: 1
                                                }), l(g, {
                                                    cols: "12"
                                                }, {
                                                    default: i(() => [l(B, {
                                                        onClick: b,
                                                        class: "float-right",
                                                        color: "accent"
                                                    }, {
                                                        default: i(() => t[36] || (t[36] = [H("提交", -1)])),
                                                        _: 1,
                                                        __: [36]
                                                    })]),
                                                    _: 1
                                                })]),
                                                _: 1
                                            })]),
                                            _: 1
                                        })]),
                                        _: 1
                                    }, 8, ["modelValue"])) : Pt("", !0)]),
                                    _: 1
                                })]),
                                _: 1
                            })]),
                            _: 1
                        })]),
                        _: 1
                    })]),
                    _: 1
                })
            }
        }
    });
export {
    nl as
    default
};