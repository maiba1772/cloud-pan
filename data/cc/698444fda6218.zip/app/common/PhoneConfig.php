<?php

namespace app\common;
use think\facade\Config as ThinkConfig;

class PhoneConfig
{
    public function __construct()
    {
        // 指定配置文件名为 'phone'
        $this->attrTConfigFileName = 'phone';

        // 加载 phone.php 的配置
        $this->attrTMasterConfig = $this->mArrayGetMasterConfig();
    }
    
    /**
     * 获取核心配置
     *
     * @return Array
     */
    public function mArrayGetMasterConfig()
    {
        return ThinkConfig::get($this->attrTConfigFileName);
    }

    /**
     * 设置核心配置
     *
     * @param array $data 要求为自动模式的Array格式
     * @return boolean
     */
    public function mBoolSetMasterConfig($data = []): bool
    {
        return $this->mBoolCoverConfig($this->attrTConfigFileName, $data, 'auto');
    }

    /**
     * 暴力搜索短信配置
     *
     * @param String $lReq_Key
     * @return Array 由深到潜排列
     */
    public function mArraySearchConfigKey($lReq_Key)
    {
        return $this->mArraySearchNestedArray($lReq_Key, $this->attrTMasterConfig);
    }

    /**
     * 搜索单维数组中的键
     *
     * @param String $searchKey
     * @param Array $Array
     * @param Array $result
     * @return Array
     */
    private function mArraySearchNestedArray($searchKey, $array, $result = '')
    {
        foreach ($array as $key => $value) {
            if ($key === $searchKey) {
                $result = $value;
                break;
            }
        }

        return $result;
    }
}