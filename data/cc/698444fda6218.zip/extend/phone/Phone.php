<?php

namespace phone;

use think\facade\Cache;
use app\common\Common;
use app\common\Base as CommonBase;

use AlibabaCloud\SDK\Dypnsapi\V20170525\Dypnsapi;
use AlibabaCloud\Credentials\Credential;
use \Exception;
use AlibabaCloud\Tea\Exception\TeaError;
use AlibabaCloud\Tea\Utils\Utils;

use Darabonba\OpenApi\Models\Config;
use AlibabaCloud\SDK\Dypnsapi\V20170525\Models\SendSmsVerifyCodeRequest;
use AlibabaCloud\Dara\Models\RuntimeOptions;

$path = __DIR__ . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';
if (file_exists($path)) {
    require_once $path;
}


class SmsShort {
    public static function createClient(){
        $lDef_AccessID = CommonBase::PhoneConf()->mArraySearchConfigKey('access_id');

        $lDef_AccessSecret = CommonBase::PhoneConf()->mArraySearchConfigKey('access_secret');

        $lDef_AccessToken = CommonBase::PhoneConf()->mArraySearchConfigKey('access_token');
        $credConfig  = new Config([
            'type' => 'sts',
            'accessKeyId' => $lDef_AccessID,
            'accessKeySecret' => $lDef_AccessSecret,
            'securityToken' => $lDef_AccessToken,
        ]);
        $credential = new Credential($credConfig);
        $config = new Config([
            "credential" => $credential
        ]);
        $config->endpoint = "dypnsapi.aliyuncs.com";
        return new Dypnsapi($config);
    }

    public static function sendVerifyCode($phoneNumber, $code){
        $client = self::createClient();
        
        $lDef_Sign = CommonBase::PhoneConf()->mArraySearchConfigKey('sign');
        $lDef_Template = CommonBase::PhoneConf()->mArraySearchConfigKey('template');
        $lDef_Param = CommonBase::PhoneConf()->mArraySearchConfigKey('param');
        
        $sendSmsVerifyCodeRequest = new SendSmsVerifyCodeRequest([
            "schemeName" => "身份验证",
            "countryCode" => "86",
            "phoneNumber" => $phoneNumber,
            "signName" => $lDef_Sign,
            "templateCode" => $lDef_Template,
            "templateParam" => str_replace('$code', (string)$code, $lDef_Param),
        ]);
        try {
            $resp = $client->sendSmsVerifyCodeWithOptions($sendSmsVerifyCodeRequest, new RuntimeOptions([]));
            
            $responseBody = $resp->body;
            if (isset($responseBody->code) && $responseBody->code !== 'OK') {
                return [
                    'success' => false,
                    'recommend' => $responseBody->message,
                    'message' => isset($responseBody->message) ? $responseBody->message : '短信发送失败',
                    'code' => $responseBody->code
                ];
            }
            
            return [
                'success' => true,
                'message' => '验证码发送成功'
            ];
        }
        catch (Throwable $error) {
            if (!($error instanceof TeaError)) {
                $error = new TeaError([], $error->getMessage(), $error->getCode(), $error);
            }
            return [
                'success' => false,
                'recommend' => isset($error->data["Recommend"]) ? $error->data["Recommend"] : null,
                'message' => '验证码发送失败'
            ];
        }
    }
}


class Phone
{
    /**
     * 限制发送间隔
     *
     * @param string $key 键名
     * @param integer $time 过期时间
     * @return boolean
     */
    protected static function cacheLog($key, $time = 60): bool
    {
        if (Cache::has($key)) {
            return true;
        } else {
            Cache::set($key, 1, $time);
            return false;
        }
    }

    /**
     * 验证码发送
     *
     * @param string $code 验证码
     * @param string $phone 手机号
     * @return array
     */
    public static function SendCaptcha($code, $phone): array
    {
        $key = hash('md5', $code . $phone);
        
        if (!self::cacheLog($key)) {
            $result = SmsShort::sendVerifyCode($phone, $code);
            
            return $result['success'] 
                ? Common::mArrayEasyReturnStruct('验证码发送成功', true)
                : Common::mArrayEasyReturnStruct('发送失败'.$result['recommend'], false);
        }
        
        return Common::mArrayEasyReturnStruct('刚刚发出，请稍后再试', false);
    }
}